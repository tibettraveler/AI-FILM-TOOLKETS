# MODULE: narrative-template-library

## Purpose
收錄可重用的角色動態展示敘事模板。模板提供「角色展示敘事」，不是 production 劇情分鏡。

## Single-character templates
1. `identity-reveal`：局部／遮蔽鋪墊，最後完整身份揭示。
2. `dress-up-final-reveal`：換裝狀態逐步建立，最後完整定裝揭示。
3. `invisible-dressing-room`：弱化場景，聚焦角色與服裝狀態變化。
4. `material-showcase`：材質、髮絲、服裝、裝甲與配件動態閱讀。
5. `emotion-build-reveal`：微表情／姿態／呼吸逐步建立到情緒高點。
6. `signature-detail-intro`：從標誌性局部進場，再回到完整角色。

## Duo / multi-character templates
7. `duo-cross-showcase`：A/B 交替展示，以節奏與視覺向量串接，不交換資產。
8. `contrast-duet`：兩角色使用互補的動作／鏡頭語言，避免長時間鏡像。
9. `relay-reveal`：A 的運動方向或構圖 cue 交給 B 接棒，再交錯 reveal。
10. `dual-final-reveal`：前段分開建立身份，最終才同框或並列完成揭示。

## Template rule
- 每個 narrative template 都必須服從 asset-binding、continuity-channels 與 motion-variation-control。
- 模板可變種，但不得以 morph / identity blending 作為跨角色連接方式。
