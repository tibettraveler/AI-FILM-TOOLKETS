# MODULE: prompt-assembly-qc

## Purpose
在輸出動態 Prompt 前，進行結構化組裝、去冗餘與風險檢查。

## Prompt order
1. Identity anchors
2. Asset binding / state
3. Shot ownership（多角色時）
4. Allowed continuity channels
5. Narrative / sequence plan
6. Motion / shot / reveal grammar
7. Variation control
8. Style / lighting / environment
9. Concise hard boundaries

## Sequence-block strategy
- 短而單純的展示可使用單一 prompt。
- 角色數、換裝狀態、武器／配件 ownership 或敘事節點增加時，優先拆成 2–4 個邏輯 sequence blocks，而不是持續膨脹成單一長 prompt。
- 每個 block 只重申必要的 identity / asset header，不重複整份規則。
- Shot 數量依時長與可讀性決定，不以「越多越好」為目標。

## Sanitization
- 合併重複否定句。
- 優先用正向描述與 ownership 規則代替大量 `no / never`。
- 移除與目標模型無關的模型名／引擎名。
- 移除無控制價值的畫質堆詞；只有確實影響任務時才保留。
- 不做不必要的逐幀／逐秒控制；只有 profile 或硬性敘事節點才保留精確時序。

## Preflight QC
輸出前確認：
- 每個角色是否有獨立 identity / asset map？
- 每個高風險 shot 是否有明確 owner？
- 角色切換時是否只承接合法 continuity channels？
- 是否有 asset crossover / mixed outfit state？
- 鏡像／重複 motion 是否過多？
- shot scale / camera direction 是否過度重複？
- reveal 是否過早或互相搶戲？
- prompt 是否存在互相矛盾或重複規則？
