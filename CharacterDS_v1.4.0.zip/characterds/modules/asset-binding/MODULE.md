# MODULE: asset-binding

## Purpose
為單／雙／多角色建立明確資產歸屬，降低服裝、武器、配件、紋樣與角色特徵交叉污染。

## Binding map
每個角色至少建立：
```text
CHARACTER_ID:
IDENTITY_ANCHORS:
OUTFIT_OWNER:
SIGNATURE_PROP_OWNER:
ACCESSORY_OWNER:
SURFACE_MARKS:
STATE_VARIANTS:
```

## Rules
- 角色既有武器／配件可以被鎖定，但不在此 module 重新設計。
- Match cut、相似握姿、相似色彩不得改變 ownership。
- 換裝／造型變體用 `STATE_A -> CUT -> STATE_B` 管理；未明示時禁止產生混合 state。
- 若同一資產確實共享，必須明示 `SHARED_ASSET`，否則預設不共享。
