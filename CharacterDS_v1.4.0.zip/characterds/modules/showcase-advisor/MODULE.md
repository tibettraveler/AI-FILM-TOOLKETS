# MODULE: showcase-advisor

## Purpose
當使用者未指定唯一動態展示方向時，主動提出 3 組具有實質差異的 showcase 方案。

## Default output
每案至少包含：
```text
SCHEME_NAME:
NARRATIVE_TEMPLATE:
PRIMARY_FOCUS:
MOTION_LANGUAGE:
SHOT_LANGUAGE:
REVEAL_STRATEGY:
VARIATION_LOGIC:
BEST_FOR:
RISK_NOTE:
```

## Default axes
視素材與角色調整，常用方向：
1. `Identity / Reveal Focus`
2. `Material / Design Focus`
3. `Contrast / Performance Focus`

雙角色時三案不得只是交換 A/B 順序；需在敘事節奏、角色分工與 reveal 策略上真正不同。
