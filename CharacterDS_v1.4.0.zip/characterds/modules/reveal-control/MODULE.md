# MODULE: reveal-control

## Purpose
控制角色在動態展示中何時、如何、以什麼節奏揭示身份。

## Reveal strategies
- `immediate-reveal`：開場即明確露出身份核心
- `progressive-reveal`：從局部逐步累積到完整角色
- `identity-reveal`：前段隱藏關鍵身份，最後完整揭示
- `expression-reveal`：以表情或情緒作為最後重點
- `silhouette-reveal`：先輪廓、後細節、最後身份

## Rules
- Reveal 只改展示節奏，不可改寫角色身份。
- 若採延後露臉，不得提前出現可辨識正臉／等價身份結構。
- Reveal 必須與 motion continuity 相容，不能為露臉而硬切成獨立擺拍。
