# MODULE: layout-system

## Purpose
讓靜態 Character DS 的局部模組可以自由替換、增減與重排，同時維持統一的視覺階層、整潔度、閱讀邏輯與設計美感。

本 module 管「版面語法」，不決定角色內容，也不取代 Identity Core。

## 1. Content roles

靜態 DS 內容先標記 role，再進行排版：

- `HERO`：主身份展示／主視覺
- `TURNAROUND`：正、側、背、3/4 等結構視圖
- `FACE`：頭部角度、五官、表情、微表情／等價身份結構
- `DETAIL`：服裝、材質、髮型、手部、鞋、裝甲、接口、紋理等局部
- `INFO`：名稱、身份、已提供設定、關鍵字
- `PALETTE`：配色、材質色、服裝色
- `POSE`：姿態、gesture、body language
- `STATE`：表情、狀態、損傷／變體（只有使用者允許時）

角色不存在某類結構時不為填滿 role 而造假。

## 2. Layout tokens

每個內容模組至少具有：

```text
ROLE: <HERO | TURNAROUND | FACE | DETAIL | INFO | PALETTE | POSE | STATE>
SIZE: <S | M | L | XL>
PRIORITY: <primary | secondary | support>
DENSITY: <low | medium | high>
ASPECT: <1:1 | 4:3 | 3:4 | 16:9 | flexible>
```

### Conceptual grid
- 靜態 Sheet 預設使用 12-column 概念格線；使用者指定版型時可覆蓋。
- `S` 約 3–4 columns；`M` 約 4–6；`L` 約 6–8；`XL` 約 8–12。
- 數值是構圖比例語法，不要求生成模型逐像素量測。

## 3. Composition invariants

1. 每張 Sheet 原則上只有 **1 個 primary visual anchor**。
2. `HERO` 若存在，通常承擔 primary；其他模組不得同時以相同視覺重量競爭。
3. 同類資訊聚類，跨類資訊以留白或清楚邊界分區。
4. 閱讀順序保持可推理：先身份／主視覺，再結構，再細節，再補充資訊。
5. 統一外框、margin、gutter、label、caption、背景與圖像裁切語言。
6. 高密度模組不得圍堵主視覺；低密度區應保留有效留白。
7. 版面需要有節奏：大型、中型、小型區塊至少形成兩級以上的視覺層次。
8. 任何模組替換後都要重新平衡鄰接模組，不得只把新內容塞入舊框。

## 4. Replacement contract

### Same-role replacement
同 ROLE 的模組可直接替換，例如：
- `FACE: expressions` ↔ `FACE: head angles`
- `DETAIL: hand` ↔ `DETAIL: footwear`

替換後重新校正 SIZE、DENSITY 與裁切，不改變角色 Identity。

### Cross-role replacement
不同 ROLE 替換時必須觸發 reflow。例如 `PALETTE` 換成 `TURNAROUND`，不可沿用原色票小格尺寸。

### Add / remove
- 新增模組：先確認 primary 不被稀釋，再決定縮放、重排或分頁。
- 移除模組：回收空間給相鄰高優先內容，不保留無意義空洞。

## 5. Density fallback

當單張版面資訊超載：

1. 保留 primary identity / hero。
2. 保留使用者明確要求的內容。
3. 次要模組可降級 SIZE 或合併為 cluster。
4. support 模組最後才壓縮。
5. 仍不足時拆成多張協同 Sheet。
6. 禁止為維持單張而靜默刪除明示內容。

## 6. Aesthetic guardrails

- 不以「填滿畫面」為目標；留白是結構的一部分。
- 不使用大量等尺寸方格把所有資訊視為同等重要。
- 不讓標籤文字壓過角色視覺。
- 不因局部模組風格不同而改變整張 Sheet 的背景、光線或排版語言。
- 美感服從可讀性與角色一致性，不以裝飾破壞辨識。
