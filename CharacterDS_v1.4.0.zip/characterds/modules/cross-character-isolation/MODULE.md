# MODULE: cross-character-isolation

## Purpose
支援雙／多角色交叉展示，避免角色身份與資產在切換、match cut、換裝與最終合流時互相污染。

## Shot ownership
每個 shot / beat 標記：
```text
SHOT_ID:
PRIMARY_SUBJECT:
VISIBLE_SECONDARY_SUBJECTS:
OWNED_OUTFIT:
OWNED_PROP:
ALLOWED_CONTINUITY:
FORBIDDEN_TRANSFER:
```

## Focal ownership
- 每個 shot 預設只有 1 個主要視覺主體；雙人同框時仍需指定 primary focal owner。
- 除非是刻意的共同高潮，不讓兩個角色同時進行高顯著度大動作，以免視線競爭。
- Screen time 可以不對稱；以角色辨識與敘事節奏優先，不追求機械式平均分配。

## Cross-cut rules
- A -> B 的切換可延續方向／節奏，但先重綁 B 的 identity / asset map。
- 高風險段落（快速連切、換裝、武器特寫、遮擋後 reveal）前後可插入 clean identity re-anchor。
- 兩人同框時，各自 silhouette / outfit / prop 必須保持可辨識分離。
- 若最終同框，先完成各自身份確認，再合流；不要用融合式轉場進入合照。

## Preferred duo patterns
- alternate focus
- call / response
- contrast action
- relay cut without asset handoff
- staggered reveal
