# MODULE: identity-core

## Purpose
建立同一角色的身份錨點、可辨識特徵與參考權限，不處理特定模板構圖。

## Rules

### Reference authority
優先序：
1. 使用者明示指令／指定主參考
2. 使用者標註 scope 的 face/body/outfit/material/accessory 參考
3. 多參考間一致的重複特徵
4. 未解衝突

同一 scope 若仍衝突，保留為 unresolved；不得平均、混臉或混成新角色。

### Identity anchors
依實際角色保留：
- 臉型／主要身份結構
- 五官或等價感知／辨識結構的位置、尺寸與比例
- 眼／感知器、眉／上眼結構、鼻／中央結構、嘴／下臉結構等可辨識關係
- 膚色／外殼色、膚質／表面材質、紋理與細微色差
- 髮色、髮長、分線／瀏海、體積、髮質或等價頭部表面結構
- 身高感、肩寬、軀幹、腰、腿或等價結構比例
- 物種特徵、機械接口、裝甲、毛髮、縫線與辨識性配件

### Scoped variation
只有被明確允許的 scope 可改變。

例如：
- expression change -> 只改表情／等價狀態，不改臉型、骨架、五官位置
- outfit change -> 只改服裝，不改 body/face identity
- background change -> 不影響角色材質與身份
- pose / camera change -> 不改角色比例

### Unknown-data policy
姓名、性格、精確年齡、職業、背景未提供時，不從外觀推定。可標示 `設定欄位 / Settings Field`、`未提供`，或在不影響模板時省略。
