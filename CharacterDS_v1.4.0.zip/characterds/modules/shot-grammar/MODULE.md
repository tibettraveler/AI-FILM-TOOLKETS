# MODULE: shot-grammar

## Purpose
提供可重用的角色動態展示鏡頭語法，不把單一來源的逐鏡編號硬編成唯一模板。

## Shot pool
- `closeup-detail`：局部材質、結構、縫線、接口、髮絲、手部等特寫
- `locked-shot`：角色自身動作提供速度，鏡頭不動
- `tracking-shot`：追隨肢體或結構的位移
- `orbit-shot`：近距離環繞，展示結構轉動
- `whip-accent`：短促強調方向變化與衝擊
- `match-cut`：以幾何、關節角度、畫面方向、運動向量承接
- `face-reveal`：身份正面揭示或等價身份 cue

## Use rules
- 遠距 body-region 切換使用硬切。
- 局部 whip 僅在同一身體區域內發生。
- 不使用 morph/melting 式轉場。
- 可混合短衝擊鏡頭與較長可讀鏡頭。
- 鏡頭語法服務於展示與辨識，不為複雜炫技而存在。
