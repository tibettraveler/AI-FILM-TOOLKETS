# MODULE: composition-advisor

## Purpose
在使用者未指定唯一靜態 DS 版面時，根據任務目的、可用素材、角色特徵與內容密度，主動提出 3 組可執行的版面搭配方案。

本 module 是「搭配顧問」，不是固定模板庫。

## 1. Trigger

預設在以下條件啟用：
- 命中靜態模板；且
- 使用者未指定唯一精確版面，或明確要求版面／模組搭配建議。

不適用於 `detail-showcase` 動態模板。

## 2. Inputs

至少評估：
- 使用目的：身份鎖定、美術設計、展示、比較等
- 角色最具辨識度的結構
- 已有參考圖／素材種類
- 使用者指定必備模組
- 可替換／可省略模組
- 畫布比例與輸出張數限制
- 內容密度與文字量

## 3. Default output: 3 schemes

預設提供 **3 組實質不同**的方案。每案至少包含：

```text
SCHEME_NAME:
PRIMARY_FOCUS:
MODULE_SET:
LAYOUT_LOGIC:
VISUAL_WEIGHT:
BEST_FOR:
TRADEOFF:
```

三案不可只是左右對調、改名稱或微調比例。

### Default strategy axes
只有在沒有更強任務訊號時，可從以下方向生成：

1. `Identity Focus`：身份辨識、臉／主結構、比例、turnaround 優先。
2. `Design Focus`：服裝、材質、配色、髮型、局部設計優先。
3. `Showcase Focus`：Hero、姿態、表情與視覺呈現優先。

這三個只是預設思考軸，不是固定模板名稱。若角色／用途不適合，應改成更合理的三案。

## 4. Recommendation rule

- 若三案中有明顯更符合任務目的者，可標記 `RECOMMENDED` 並用一句話說明原因。
- 仍需保留另外兩案，讓使用者有可比較的方向。
- 若使用者要求「直接做，不用選」，可在內部完成三案比較，選擇最合適方案執行；不必阻塞流程。

## 5. Material-aware behavior

- 沒有表情素材／需求時，不為了湊方案硬塞 Expression。
- 非人型角色不強迫使用真人五官與人體模組。
- 參考圖不足時，方案應降低對缺失資訊的依賴，而不是臆測內容。
- 使用者指定模組時，三案都必須保留該模組，只改變組合方式與視覺權重。

## 6. Quality gate

每個方案提交前確認：
- 是否有唯一視覺主角？
- 是否遵守 layout-system？
- 是否可由現有素材完成？
- 是否維持 Identity？
- 是否與另外兩案有真正差異？
- 是否清楚說明用途與取捨？
