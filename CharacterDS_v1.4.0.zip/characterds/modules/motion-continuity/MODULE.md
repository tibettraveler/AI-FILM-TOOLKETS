# MODULE: motion-continuity

## Purpose
維持動態展示中的身體／結構連續性，避免每次切鏡後角色重置為中立姿勢或失去重量感。

## Core rules
- 切鏡後延續：張力、承重、重心、旋轉慣性、動作方向。
- 頭髮、布料、柔性附件、機械連接與活動裝甲需保留 follow-through。
- 動作必須有物理因果：啟動、施力、承重、釋放、穩定。
- 非人型／機械角色用等價結構替代人體術語。

## Default motion arc
若使用者未指定，可使用：
```text
setup -> build -> release -> settle/reveal
```

此 arc 可對應轉身、換裝、整理服裝、情緒建立、姿態轉換等，不綁死單一動作。
