# MODULE: motion-variation-control

## Purpose
控制動作、方向、鏡位與節奏變異，降低鏡像與重複造成的視覺疲勞。

## Variation ledger
追蹤：
- motion family
- body region
- movement direction
- camera movement
- shot scale
- kinetic intensity
- reveal state
- silhouette / pose family
- focal-owner cadence

## Default rules
- 雙角色預設**互補**而非鏡像。
- 相同 motion family 不連續重複過多次。
- 相同 camera direction / shot scale 應交錯變化。
- 每段展示至少建立一個節奏對比：快/慢、動/靜、近/遠、強/柔。
- 鏡像 pair 原則上只作一次性設計亮點；除非使用者明確要求對稱主題。
- 不讓同一角色長時間只以相同 silhouette / pose family 出現。
- 雙角色交叉時避免 A/B/A/B 的機械式等距節拍，可透過 2:1、長短鏡交錯或延後 reveal 打破規律。

## Contrast examples
- A 大幅轉身 -> B 微表情近景
- A 強動作 -> B 材質／手部細節
- A 先 reveal -> B 延後 reveal
- A 正向移動 -> B 斜向或垂直承接
