# MODULE: continuity-channels

## Purpose
把跨鏡「連續性」拆成不同 channel，避免把動作延續誤當成角色資產延續。

## Channels
```text
IDENTITY
ANATOMY
OUTFIT
PROP
ACCESSORY
MOTION
RHYTHM
CAMERA_DIRECTION
LIGHTING
NARRATIVE_BEAT
```

## Default inheritance
- 同一角色連續 shot：可依需要繼承全部已鎖定 channel。
- 角色 A -> 角色 B：預設只允許 `MOTION / RHYTHM / CAMERA_DIRECTION / NARRATIVE_BEAT` 承接。
- `IDENTITY / ANATOMY / OUTFIT / PROP / ACCESSORY` 在角色切換時必須重新綁定 owner。

## Principle
> Continuity is selective inheritance, not global inheritance.
