# MODULE: static-motion-bridge

## Purpose
把靜態 Character DS 轉成動態展示節點，使靜態圖板與動態影片形成同一角色的配套資產。

## Static inputs
- identity anchors
- hero view
- turnaround / silhouette
- signature details
- outfit / material anchors
- expression set
- pose cues

## Bridge logic
1. 先選 3–6 個最具辨識度的靜態 anchor。
2. 每個 anchor 對應一個 dynamic beat，而非逐項全部拍攝。
3. 動態展示只重新編排與表演既有 anchor，不新增未定義造型。
4. 靜態與動態可使用不同構圖，但 identity / asset ownership 必須一致。
5. 多角色 paired output 分別建立各自 bridge，再做 cross showcase。
