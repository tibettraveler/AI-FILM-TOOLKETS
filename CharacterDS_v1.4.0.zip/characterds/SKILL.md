---
name: characterds
description: "根據參考圖建立一致的角色 DS，支援身份鎖定、角色設定板與動態展示。"
---

# CharacterDS v1.4.0

CharacterDS 是獨立發展的**角色深度 DS**技能。它根據角色參考資料建立一致、可重複使用的角色展示資產，涵蓋靜態美術設定、身份固定、動態人物介紹、交叉展示與動靜配套。

CharacterDS 專注在**角色本身如何被深度定義與展示**，不是 AFPT 的流程整合器，也不是 production / generation-control DS。

## Core Role

1. 鎖定單一或多個角色各自的身份、結構與主要視覺特徵。
2. 對靜態 DS 提供模組化版面系統與 3 組主動搭配建議。
3. 對動態 DS 提供可組裝的 motion / shot / reveal / narrative 展示語法。
4. 對雙角色／多角色展示建立明確 asset ownership、shot ownership 與交叉污染防護。
5. 把「動作連續」與「身份／資產繼承」分開管理，允許節奏承接但禁止錯誤資產跨角色延續。
6. 控制鏡像、重複動作、運鏡方向與節奏重複，降低視覺疲勞。
7. 支援靜態 DS 到動態展示的內部轉譯，形成真正的 `static+motion-paired` 輸出。
8. 組裝 Prompt 前進行優先級整理、去冗餘與風險檢查。

設計原則：

> **Same identity. Bound assets. Controlled inheritance. Varied presentation.**

## 0. 核心不變條件

1. **Identity first**：角色身份幾何、身體結構、比例與主要辨識特徵優先於版面、鏡頭與展示效果。
2. **No anatomy invention**：不得為滿足通用模板而憑空增加角色不存在的身體部位、配件、武器、裝甲或機械結構。
3. **Unknown stays unknown**：未提供的姓名、人格、精確年齡、職業、背景等不得僅憑外觀臆測。
4. **Scoped reference authority**：臉、身體、服裝、材質、配件等參考只控制各自 scope；同 scope 衝突未解時不得混成新角色。
5. **Asset ownership**：多角色任務中，每項服裝、武器、配件、紋樣與狀態必須有明確 owner；不得因 match cut 或動作承接而跨角色漂移。
6. **Scoped variation**：只修改使用者允許變更的 scope；表情、服裝、背景、姿態或鏡位變更不得連帶改寫 Identity。
7. **State-change clarity**：換裝、配件切換、造型變體只能在明確狀態節點變更；未指定時不得產生半套 A＋半套 B 的混合狀態。
8. **Family / template isolation**：靜態構圖、鏡頭設計、露臉規則、時長、shot profile 與敘事模板不得跨 family 繼承。
9. **Layout integrity**：靜態 DS 的局部模組可替換，但視覺主次、格線、間距、閱讀順序與資訊密度必須重新平衡。
10. **Motion integrity**：動態 DS 的局部鏡頭與動作模組可替換，但必須維持動作連續性、重心轉移、材質跟隨與 reveal 邏輯。
11. **Controlled continuity**：跨鏡繼承需分 channel 管理；Motion / Rhythm 可承接，不代表 Identity / Outfit / Prop 可以承接。
12. **Variation over mirroring**：鏡像／對稱動作只作為刻意強調手段，不作為雙角色展示的預設節奏。
13. **No silent deletion**：資訊過量時不得靜默刪除使用者明確要求內容；應重排、降級次要模組或拆分多張／多支協同輸出。
14. **Minimal loading**：只載入命中的 family、template 與必要 modules。
15. **Prompt economy**：優先使用正向、結構化、具作用域的提示；去除重複否定、模型綁定與沒有實際控制價值的修飾詞。
16. **No false generation claim**：目前模板若不符合「生成用 DS」需求，不得把美術設定／宣傳展示模板重新包裝成生成專用規格。
17. **NO_TEMPLATE_MATCH is valid**：沒有適合模板時可明確回報模板缺口；不得硬套最接近模板。
18. **Independent development**：不預設任何外部系統、平台或工作流的界接契約。

## 1. 最小路由狀態

```text
REQUEST_PURPOSE: <setting | identity-reference | presentation | generation-control | unknown>
OUTPUT_MEDIUM: <static | video | mixed | unknown>
PRESENTATION_MODE: <static-only | motion-only | static+motion-paired | multi-variant-showcase | unknown>
SUBJECT_COUNT: <single | duo | multi | unknown>
LAYOUT_INTENT: <fixed | adaptive | advisor | n/a>
SHOWCASE_INTENT: <fixed | advisor | n/a>
ACTIVE_FAMILY: NONE
ACTIVE_TEMPLATE: NONE
LOADED_MODULES: NONE
ROUTE_STATUS: UNRESOLVED
```

## 2. Runtime 載入順序

```text
SKILL.md
  -> router/INDEX.md
  -> router/families/<matched-family>.md
  -> templates/<matched-template>/MANIFEST.md
  -> templates/<matched-template>/TEMPLATE.md
  -> modules/<explicitly-allowed-module>/MODULE.md
```

不得預先載入所有模板比較內容。

## 3. 輸入解析

至少辨識：
- 角色參考圖／參考資料
- 使用者已明示的角色事實
- subject count（單／雙／多角色）
- 每個角色的 identity / outfit / prop / accessory ownership
- 參考圖 scope（face/body/outfit/material/accessory 等）
- 使用目的與輸出 medium
- 允許變更項目與 state changes
- 必須保留／可替換的內容模組
- 靜態版面或動態展示是否已指定
- 敘事展示偏好（若有）
- 未知欄位

## 4. Router

路由只由 `router/` 決定。`templates/` 不得自行擴大命中範圍。

目前支援：
- 靜態美術設定圖
- 身份固定／Identity Lock 參考板
- 單角色動態展示／人物介紹蒙太奇
- 雙角色／多角色交叉展示
- 動靜搭配輸出

目前**尚未註冊專門的 production / generation-control Character DS 模板**。生成流程控制需求應標記 `NO_TEMPLATE_MATCH`。

## 5. 靜態 Presentation 行為

命中靜態模板時：
1. 載入 `layout-system`。
2. 未指定唯一版面時，載入 `composition-advisor`，預設提出 **3 組版面搭配方案**。
3. 三方案必須由實際角色素材、用途與內容密度推導。
4. 使用者要求直接執行時，可內部比較三案後採用最合適方案。

## 6. 動態 Presentation 行為

命中動態模板時，基礎載入：
- `motion-continuity`
- `shot-grammar`
- `reveal-control`
- `asset-binding`
- `continuity-channels`
- `motion-variation-control`
- `prompt-assembly-qc`

條件載入：
- 雙／多角色 -> `cross-character-isolation`
- 未指定唯一展示方向 -> `showcase-advisor`
- 需要敘事變種 -> `narrative-template-library`
- `static+motion-paired` -> `static-motion-bridge`

動態展示優先組裝：
```text
IDENTITY + ASSET MAP + CONTINUITY CHANNELS
+ MOTION MODULES + SHOT GRAMMAR + REVEAL
+ OPTIONAL NARRATIVE TEMPLATE
+ VARIATION CONTROL
+ PROMPT QC
```

## 7. 多角色展示規則

多角色任務必須建立：
```text
CHARACTER_A: identity / outfit / prop / accessory / state
CHARACTER_B: identity / outfit / prop / accessory / state
...
SHOT_OWNERSHIP: 每鏡主體與可見資產
TRANSFERABLE_CHANNELS: motion / rhythm / camera-direction / narrative-beat
NON_TRANSFERABLE_CHANNELS: identity / outfit / prop / anatomy / signature-mark
```

角色切換時可以延續運動方向、節奏、構圖向量，但不得自動延續另一角色的資產。

## 8. 動作變異與疲勞控制

- 雙角色展示預設採**互補**而非鏡像。
- 同一動作型、同一運鏡方向、同一 shot scale 不應長時間連續重複。
- 若使用鏡像動作，必須具有明確目的，例如一次性的對稱高潮或雙人呼應。
- 優先建立「A 強動作 / B 細節回應」、「A 大幅 / B 靜態張力」、「A 先 reveal / B 後 reveal」等差異。

## 9. Static–Motion Bridge

動靜搭配時，靜態 DS 可提供：
- signature details
- identity anchors
- outfit / material anchors
- expression set
- pose / silhouette cues

動態展示只能把這些資料轉成展示節點，不得在轉譯過程新增未定義資產。

## 10. Prompt Assembly

Prompt 組裝優先級：
1. Identity anchors
2. Asset ownership / state
3. Allowed variations
4. Narrative / sequence intent
5. Motion / shot grammar
6. Reveal / variation strategy
7. Style / lighting / quality
8. Concise hard boundaries

重複否定、模型名稱、無控制作用的畫質堆詞、逐鏡冗餘應在輸出前清理。

## 11. 輸出原則

- 使用者要 Prompt：輸出可直接使用的 Prompt，不附加不必要教學。
- 使用者要 DS／規格：輸出結構化 DS。
- 使用者要版面建議：預設提供 3 組可執行搭配方案。
- 使用者要動態展示建議：預設提供 3 組展示方案，除非已指定唯一方向。
- 使用者要動靜配套：拆成靜態與動態 phase，共享身份核心與已確認資產。
- 無已註冊模板：標記模板缺口，不虛構能力。

## 12. Dev plane

`dev/` 僅供維護、驗證與擴充模板時使用；正常 runtime 不載入。
