# CharacterDS Family Router

## Routing fingerprint
- `REQUEST_PURPOSE`
- `OUTPUT_MEDIUM`
- `PRESENTATION_MODE`
- `SUBJECT_COUNT`
- `OBJECT`
- `LAYOUT_INTENT`
- `SHOWCASE_INTENT`

## Families
| family_id | 進入條件 | router |
|---|---|---|
| `FAMILY-STATIC-PRESENTATION` | 角色美術設定、身份參考、角色圖板 | `families/static-presentation.md` |
| `FAMILY-DYNAMIC-PRESENTATION` | 角色動態展示、人物介紹蒙太奇、單／雙／多角色交叉展示 | `families/dynamic-presentation.md` |

## Presentation modes
- `static-only`
- `motion-only`
- `static+motion-paired`
- `multi-variant-showcase`

## Subject modes
- `single`
- `duo`
- `multi`

## NO_TEMPLATE_MATCH
不得硬路由：
- production / generation-control Character DS
- 模型特定 conditioning package
- 角色＋商品／物件設計板
- Prop 設計本身（但可保留角色既有 signature prop 作為綁定資產）
- 尚未註冊的新 DS 類型
