# FAMILY-STATIC-PRESENTATION Router

## TEMPLATE-ART-SETTING-SHEET

### MATCH
- 主要目的為角色美術設定板、Character Sheet、Character Bible、turnaround、表情／細節設定板。
- 輸出為靜態 DS／單張或多張協同設定板。

### EXCLUDE
- 主要目的只是固定同一角色身份供後續變體使用。
- 主要目的為動態角色展示影片。
- 主要目的為 production generation-control DS。

### ROUTE
```text
ACTIVE_TEMPLATE: art-setting-sheet
TEMPLATE_PATH: templates/art-setting-sheet/MANIFEST.md
STATIC_LAYOUT_MODULES: layout-system + composition-advisor
```

## TEMPLATE-IDENTITY-LOCK-SHEET

### MATCH
- 主要目的為固定臉、固定同一角色、identity lock、same-character reference、角色身份固定表。
- 重點是可辨識身份與比例，不是完整美術展示。

### EXCLUDE
- 主要目的是完整角色美術設定板。
- 主要目的是動態展示。
- 要求的是生成流程控制契約，而非身份參考表。

### ROUTE
```text
ACTIVE_TEMPLATE: identity-lock-sheet
TEMPLATE_PATH: templates/identity-lock-sheet/MANIFEST.md
STATIC_LAYOUT_MODULES: layout-system + composition-advisor
```

## Multi-output

若使用者明確同時要求靜態設定＋動態展示：

```text
DECOMPOSE_INTO_PHASES:
  - <art-setting-sheet OR identity-lock-sheet>
  - detail-showcase
PRESENTATION_MODE: static+motion-paired
```
