# Legacy note

本檔自 v1.3.0 起由下列 family router 取代：
- `families/static-presentation.md`
- `families/dynamic-presentation.md`

保留本檔僅供版本回溯，不作 runtime 使用。
