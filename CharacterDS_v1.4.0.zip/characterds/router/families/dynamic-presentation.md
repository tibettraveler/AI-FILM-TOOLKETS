# FAMILY-DYNAMIC-PRESENTATION Router

## TEMPLATE-DETAIL-SHOWCASE

### MATCH
- 影片、montage、人物介紹、角色動態展示、細節展示、身份揭示、雙角色／多角色交叉展示。
- 目的是角色 presentation / showcase，而非 production narrative control。

### ROUTE
```text
ACTIVE_TEMPLATE: detail-showcase
TEMPLATE_PATH: templates/detail-showcase/MANIFEST.md
BASE_MODULES:
  - motion-continuity
  - shot-grammar
  - reveal-control
  - asset-binding
  - continuity-channels
  - motion-variation-control
  - prompt-assembly-qc
CONDITIONAL_MODULES:
  duo-or-multi -> cross-character-isolation
  showcase-unspecified -> showcase-advisor
  narrative-variant -> narrative-template-library
  paired-output -> static-motion-bridge
```

## Multi-character default
`SUBJECT_COUNT: duo | multi` 時，不把角色 B 當作角色 A 的變種；每個角色都必須有獨立 identity / asset map / shot ownership。

## EXCLUDE
- 靜態 Character Sheet / Identity Lock。
- production shot generation DS、Segment continuity contract。
- merchandise board / character-product design。
