# SOURCE MAP

## Core sources
- `角色DS.md`：靜態角色設定板基本結構與品質要求。
- `任務prompt_已整理.docx`：Character Sheet 模組內容池與一致性要求。
- `人物美術設定集DS提示詞.docx`：Identity Lock、未知資訊不得臆測、同一角色臉部結構不變。
- `人物介紹_整理版.docx`（前 1–21 頁）：動態展示語法、動作連續性、材質跟隨、鏡頭語法、reveal 控制與敘事模板。
- `Hyou × Yuna 30s.mp4`：雙角色交叉展示壓力測試；暴露跨角色資產污染、局部身份／服裝漂移、鏡像動作與重複節奏疲勞問題，用於 v1.4.0 的 asset binding、continuity channels、cross-character isolation 與 motion variation 規則。

## Explicit exclusions
- `人物介紹_整理版.docx`（22–28 頁）中的 Character × Object / merchandise board / 商品應用不納入 CharacterDS 主體。
- MiniMax H3 或其他模型綁定表述不升格為核心規則。
- 固定 15 秒／20 鏡逐鏡腳本保留為 profile，不升格為全域預設。
