# Motion variation regression cases
1. 雙角色預設不使用長序列鏡像動作。
2. 連續相同 motion family / shot scale / camera direction 應被標記。
3. 至少存在一個快慢、動靜或近遠對比。
4. 對稱鏡像若出現，應有明確設計目的。
