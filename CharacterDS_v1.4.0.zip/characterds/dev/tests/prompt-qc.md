# Prompt assembly / QC regression cases
1. Identity / asset ownership 必須排在 shot style 前。
2. 重複否定句應合併。
3. 模型特定名稱不進核心 prompt，除非使用者指定。
4. 無控制價值的畫質堆詞應移除。
5. 非必要逐秒／逐幀控制應刪減。
