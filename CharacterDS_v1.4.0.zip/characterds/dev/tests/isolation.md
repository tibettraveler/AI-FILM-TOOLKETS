# Isolation regression cases
1. static layout modules 不注入 dynamic。
2. dynamic shot / reveal modules 不污染 static。
3. A -> B 切換不可繼承 identity / outfit / prop。
4. motion / rhythm 可跨角色承接。
5. signature prop ownership 不因 match cut 改變。
6. narrative template 不得覆寫 asset-binding。
