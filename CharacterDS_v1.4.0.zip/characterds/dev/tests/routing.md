# Routing regression cases
1. Character Sheet -> static / art-setting-sheet
2. Identity Lock -> static / identity-lock-sheet
3. single montage -> dynamic / detail-showcase
4. duo cross showcase -> dynamic / detail-showcase + cross-character-isolation
5. static + motion -> two phases + static-motion-bridge
6. merchandise / object design -> NO_TEMPLATE_MATCH
7. generation-control DS -> NO_TEMPLATE_MATCH
