# Advisor regression cases
1. static 未指定版面 -> composition-advisor 3 案。
2. dynamic 未指定展示方向 -> showcase-advisor 3 案。
3. duo 3 案需在角色分工、節奏與 reveal 上實質不同。
4. 使用者指定唯一方向時不強制列 3 案。
