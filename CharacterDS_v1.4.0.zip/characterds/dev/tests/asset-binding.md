# Asset binding regression cases
1. A 的武器不得漂到 B。
2. B 的服裝／紋樣不得混入 A。
3. 換裝只能在明確 state change 發生。
4. shared asset 必須明示。
5. 高風險交叉切換可使用 identity re-anchor。
