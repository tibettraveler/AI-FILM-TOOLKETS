# Layout regression cases

1. FACE / DETAIL / HERO / PALETTE 任意替換後仍維持版面主次
2. 資訊過量時不得靜默刪除，應重排或拆張
3. 3 組版面方案需具有實質差異
4. paired output 只共用 identity，不共用 layout rule
