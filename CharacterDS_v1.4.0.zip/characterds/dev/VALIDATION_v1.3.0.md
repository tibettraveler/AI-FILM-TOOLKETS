# CharacterDS v1.3.0 Validation

## Scope
- 驗證 v1.3.0 架構調整：Static / Dynamic 雙 family、Dynamic Presentation modules、Paired Output 模式、Narrative Template Library、排除 merchandise 段落。

## Results
- Total checks: 36
- PASS: 36
- FAIL: 0

## Validation summary
1. `VERSION`、README、SKILL 描述一致升為 1.3.0。PASS
2. router 已由單 family 升為 `static-presentation` / `dynamic-presentation`。PASS
3. 靜態命中 `art-setting-sheet` / `identity-lock-sheet`。PASS
4. 動態命中 `detail-showcase`。PASS
5. `static+motion-paired` 會拆 phase，而非混成單模板。PASS
6. `multi-variant-showcase` 已註冊為輸出模式。PASS
7. `motion-continuity`、`shot-grammar`、`reveal-control`、`narrative-template-library` 已存在。PASS
8. `detail-showcase` 已從固定長 prompt 轉為 Dynamic Presentation 模板。PASS
9. 15 秒 / 20 鏡逐鏡設計已降級為 source-faithful montage profile。PASS
10. 第一批敘事模板已註冊 6 項。PASS
11. 商品／物件設計段被明確排除。PASS
12. `composition-advisor` 僅適用靜態 family。PASS
13. paired output 共用 identity，但不共享 layout / shot 規則。PASS
14. `NO_TEMPLATE_MATCH` 保留有效。PASS
15. AFPT 依賴未被引入。PASS

## Packaging checks
- ZIP 結構完整。PASS
- manifest 已更新。PASS
- SHA256SUMS 已重建。PASS
