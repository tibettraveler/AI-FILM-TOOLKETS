# CharacterDS v1.2.0 Validation

## Result

**PASS** — 本版屬能力層擴充，不需要架構重構。Router、三個既有 Template 與獨立發展邊界均維持成立。

## Validation scope

- 命名／技能描述
- Router / Template isolation
- Identity scope consistency
- 模組化版面語法
- 3-scheme Composition Advisor
- 非人型／機械適配
- generation-control 缺口保留
- 外部系統耦合檢查
- 封裝與路徑完整性

## Automated checks

共執行 **32 項結構／語義檢查，32 PASS / 0 FAIL**。

### Core checks

| 項目 | 結果 | 說明 |
|---|---|---|
| 名稱 `CharacterDS` / `characterds` | PASS | 未改名 |
| 技能簡介 | PASS | 維持已確認文字 |
| Template 數量 | PASS | 維持 3 個，未因新 Prompt 增加同質模板 |
| `layout-system` | PASS | 靜態 DS 可用，支援 role / size / priority / density / aspect |
| `composition-advisor` | PASS | 靜態 DS 未指定唯一版面時預設 3 案 |
| Showcase 隔離 | PASS | `detail-showcase` 不載入靜態 layout/advisor |
| Identity scope | PASS | expression / outfit / pose 等局部變更不改寫 Identity |
| 非人型適配 | PASS | 不為填模板新增不存在結構 |
| `NO_TEMPLATE_MATCH` | PASS | generation-control 缺口仍保留 |
| Runtime 外部耦合 | PASS | Runtime 無 AFPT 或其他特定外部系統依賴 |

## Layout validation

通過以下情境：

1. `FACE: expressions` 與 `FACE: head angles` 可同 role 替換並重新校正密度。
2. `PALETTE` 改為 `TURNAROUND` 時強制 reflow，不沿用色票小格。
3. 新增高密度 DETAIL 時不允許稀釋 primary HERO。
4. 移除 secondary module 後回收空間，不留下無效空洞。
5. 單張超載時可拆多張協同 Sheet，不靜默刪除明示內容。
6. 模組替換後仍維持 margin / gutter / label / background / hierarchy 一致。

## Advisor validation

- 預設產出 3 組**實質不同**方案，而非左右鏡像或改名稱。
- 使用者指定必備模組時，三案均保留，只調整組合與視覺權重。
- 素材不足時降低依賴，不臆測補齊。
- 非人型角色依實際結構重組方案。
- 有明顯最佳案時可標記 `RECOMMENDED`，但仍保留另外兩案。
- 使用者要求直接執行時，可內部比較三案後直接採用最佳方案，不阻塞任務。

## Source absorption decision

新增來源內容只吸收可泛化規則：

- 色票、輪廓、表情／微表情、頭部、手部、服裝／材質細節 -> 納入既有 `art-setting-sheet` 的 Content Module Pool。
- 臉部結構、髮型、皮膚／表面、身體比例、表情只改狀態不改 Identity -> 強化 `identity-core` / `identity-lock-sheet`。
- 範例姓名、人格、成人女性、Photorealistic、Cafe／Travel 等實例偏好 -> 不升格為全域規則。

## Non-goals preserved

- 未新增 production / generation-control Character DS。
- 未新增 Prop / Scene 分區。
- 未新增外部 Service Contract、handoff、API 或 AFPT 專屬治理層。
- CharacterDS 維持獨立發展。

## Verdict

v1.2.0 可作為下一階段穩定基線。後續若只是增加版面模組或完善搭配策略，優先擴充 `layout-system` / `composition-advisor`；只有出現真正新用途時才增加 Template 或 Family。
