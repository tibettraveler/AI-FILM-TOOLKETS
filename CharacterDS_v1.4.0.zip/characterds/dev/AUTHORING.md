# AUTHORING GUIDE

## Positioning
CharacterDS = 角色深度 DS。優先發展角色靜態／動態展示專業，不為外部系統整合而提前改寫內部架構。

## New source absorption rule
新 Prompt / 影片 /案例進入 CharacterDS 時，先判斷它提供的是：
1. Identity rule
2. Asset ownership rule
3. Layout grammar
4. Motion grammar
5. Shot grammar
6. Reveal strategy
7. Narrative template
8. Variation / fatigue control
9. Prompt assembly / QC rule

只有真正新的輸出目的才建立新 template；其餘優先抽成 module / profile / narrative variant。

## Multi-character rule
雙／多角色案例必須先建立 asset map 與 continuity channels，再談交叉剪接。不得用大量否定句取代 ownership 設計。

## Prompt economy
- 不把長 Prompt 原樣收錄成核心。
- 移除模型綁定、重複否定、無效畫質堆詞。
- 保留真正影響角色身份、資產、連續性、節奏與 reveal 的控制資訊。

## Static–motion rule
動靜配套只在 CharacterDS 內共享 identity / asset anchors；靜態 layout 與動態 shot grammar 仍分離。
