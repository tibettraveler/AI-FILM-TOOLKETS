# CHANGELOG

## v1.4.0
- 新增 `asset-binding`：角色／服裝／武器／配件／狀態 ownership。
- 新增 `continuity-channels`：把跨鏡繼承拆分為 Identity / Asset / Motion / Rhythm / Camera / Narrative 等 channel。
- 新增 `cross-character-isolation`：雙／多角色 Shot Ownership、re-anchor 與交叉污染防護。
- 新增 `motion-variation-control`：降低鏡像、重複 motion、重複 shot scale / camera direction 造成的視覺疲勞。
- 新增 `static-motion-bridge`：由靜態 DS anchor 生成動態展示節點。
- 新增 `showcase-advisor`：動態展示未指定唯一方向時預設提出 3 案。
- 新增 `prompt-assembly-qc`：Prompt 優先級、去冗餘、模型中立化與 preflight QC。
- 新增雙角色敘事模板：`duo-cross-showcase`、`contrast-duet`、`relay-reveal`、`dual-final-reveal`。
- 角色既有 signature prop 可綁定，但 CharacterDS 不承擔 Prop 設計。
- Hyou × Yuna 30s 作為交叉展示壓力測試樣本，納入污染與鏡像疲勞防護規則來源。

## v1.3.0
- 正式建立 Static / Dynamic Presentation 雙 family。
- 新增 motion-continuity、shot-grammar、reveal-control、narrative-template-library。
- detail-showcase 升級為 Dynamic Presentation 基礎模板。
- 支援 static-only / motion-only / static+motion-paired / multi-variant-showcase。

## v1.2.0
- 新增 layout-system 與 composition-advisor。
- 靜態 DS 改為模組化 Content Pool。
