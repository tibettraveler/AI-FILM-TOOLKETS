# CharacterDS

根據參考圖建立一致的角色深度 DS，支援身份鎖定、靜態美術設定圖、動態展示影片與動靜搭配展示包。

## Registered families
- `static-presentation`：靜態美術設定與身份固定參考
- `dynamic-presentation`：角色動態展示、人物介紹蒙太奇、單／雙／多角色交叉展示

## v1.4.0 core upgrades
- `asset-binding`：角色／服裝／武器／配件／狀態歸屬鎖定
- `continuity-channels`：分離身份、資產、動作、鏡頭、光線、敘事的跨鏡繼承
- `cross-character-isolation`：雙／多角色 Shot Ownership 與交叉污染防護
- `motion-variation-control`：降低鏡像、重複動作與相同運鏡造成的視覺疲勞
- `static-motion-bridge`：把靜態 DS 的身份與標誌細節轉成動態展示節點
- `showcase-advisor`：動態展示未指定唯一方向時，預設提出 3 組展示方案
- `prompt-assembly-qc`：組裝與清理 Prompt，檢查資產、繼承、重複度與無效提示

## Positioning
CharacterDS 定位為「角色深度 DS」：
- 靜態面：Character Sheet、Identity Lock、美術設定圖
- 動態面：人物介紹蒙太奇、身份揭示、材質／情緒／姿態展示、交叉展示
- 配套面：`static-only`、`motion-only`、`static+motion-paired`、`multi-variant-showcase`

目前仍**不註冊** production / generation-control Character DS，亦不納入角色＋商品／物件設計模板。角色既有武器／配件可作為角色身份資產被鎖定，但不在 CharacterDS 內重新設計 Prop。
