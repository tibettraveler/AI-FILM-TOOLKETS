# TEMPLATE-ART-SETTING-SHEET Manifest

```text
TEMPLATE_ID: art-setting-sheet
PURPOSE_CLASS: ART_SETTING
MEDIUM: STATIC
TEMPLATE_FILE: TEMPLATE.md
DEFAULT_MODULES:
  - identity-core
  - anatomy-adaptation
  - quality-consistency
  - layout-system
  - composition-advisor
ALLOWED_MODULES:
  - identity-core
  - anatomy-adaptation
  - quality-consistency
  - layout-system
  - composition-advisor
```

## Boundary
本模板是角色美術設定／presentation reference，不宣稱為 production generation-control DS。
