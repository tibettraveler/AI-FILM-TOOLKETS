# Art Setting Sheet

## Purpose
建立角色美術設定／視覺參考 Sheet。版面採模組化組合，不要求每次塞入固定全套內容。

## Default canvas
- 4:3 橫版；若使用者／目標輸出另有指定則覆蓋。
- 白／暖白／米白／極簡背景。
- 乾淨技術／編輯式排版，無 Logo、無浮水印。
- 由 `layout-system` 決定視覺主次與 reflow。

## Content module pool
依角色實際結構與任務目的選用，不為填滿模板而造假。

### INFO
- 姓名、身份、年齡、性格、核心主題：只填已提供資料

### PALETTE
- 6–8 色塊或依角色實際色彩系統調整

### HERO
- 主身份展示：正面／3/4 主視覺、胸像或全身，依用途選擇

### TURNAROUND
- 正面、3/4、側面、背面；必要時 3/4 背面
- 可附比例線／身高刻度

### FACE
可選：
- Head / Primary Identity Angles：3/4、側面、仰視、俯視
- Expression：平靜、好奇、緊張、驚訝、害怕、悲傷、堅定、放鬆
- Micro-expression / Micro-state：眼／感知結構張力、微笑／正向微狀態、嘴／下顎張力、微恐懼／緊張、呼吸／idle 控制
- Face Parts：眼／感知器、眉／上眼結構、鼻／中央結構、嘴／下臉結構、耳／側部結構

### DETAIL
可選：
- 髮型／主結構
- 皮膚／表面材質
- 服裝材質、縫線、裝甲、接口
- 手／Manipulator
- 鞋／下部接觸結構
- 辨識性配件

### POSE
- 放鬆、緊張、自信或使用者指定 body language

### SILHOUETTE
- 可作 `DETAIL` 或 `TURNAROUND` 子模組：正面、側面

## Default composition behavior
- 至少包含 1 個 primary identity visual。
- 其餘內容從 module pool 依目的選擇，不預設所有模組都必須出現。
- 未指定唯一版面時，`composition-advisor` 先提出 3 組搭配方案。
- 使用者明確要求的模組必須保留於三案中。

## Layout fallback
若單張畫面密度過高：
- 使用者未要求單圖時，可拆成多張協同 Sheet。
- 使用者要求單圖時，優先保留 primary identity 與明示內容，重排或壓縮 support 模組。
- 不得靜默刪除使用者明確要求項目。
