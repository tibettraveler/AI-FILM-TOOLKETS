# TEMPLATE-IDENTITY-LOCK-SHEET Manifest

```text
TEMPLATE_ID: identity-lock-sheet
PURPOSE_CLASS: IDENTITY_REFERENCE
MEDIUM: STATIC
TEMPLATE_FILE: TEMPLATE.md
DEFAULT_MODULES:
  - identity-core
  - anatomy-adaptation
  - quality-consistency
  - layout-system
  - composition-advisor
ALLOWED_MODULES:
  - identity-core
  - anatomy-adaptation
  - quality-consistency
  - layout-system
  - composition-advisor
```

## Boundary
本模板是 same-character 身份參考／固定表，不等同模型特定 conditioning package 或跨鏡頭生成控制契約。
