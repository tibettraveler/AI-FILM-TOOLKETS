# Identity Lock Sheet

## Purpose
集中記錄未來重現同一角色時最重要的身份錨點，而非補寫故事設定。可自由組合局部模組，但任何變體不得改寫 Identity。

## Identity data pool
只記錄已提供或可直接觀察的項目：
- Name / Settings Field
- Age（使用者提供；不由外觀估精確數字）
- Personality / Settings Field
- facial / primary identity outline
- eye / sensor shape and spacing
- eyebrow / upper-eye structure
- nose / central structure
- mouth/lip / lower-face structure
- hair color / length / parting or bangs / volume / texture
- skin / outer-surface tone, texture and subtle variation
- height impression
- body type / mass silhouette
- shoulder width, torso/core, waist/joint region, leg/support proportions
- basic clothing / shell / armor system

## Optional reference modules

### Whole-structure angles
在同一簡潔／典型服裝與同一髮型／主結構下：
- front
- side
- back
- diagonal front
- diagonal back

保持身高、肩／機體寬、軀幹／核心、腰／關節區、腿／支撐長度一致。

### Face / primary identity angles
- front
- 45° diagonal
- profile
- diagonal from above
- diagonal from below

骨架／結構幾何與部件位置必須一致。

### Expressions / state checks
可加入 Neutral、Natural Smile、Serious、Surprised、Troubled 或等價狀態。

**只改 expression/state，不改角色臉型、骨架、五官位置或主要身份結構。**

### Detail checks
依角色需要選用：
- eyes / sensors
- eyebrows / upper-eye structure
- nose / central structure
- mouth / lower-face structure
- ears / side structure
- hair / primary head surface
- skin / outer-surface close-up
- hands / manipulators
- shoulder / abdomen-core / back / legs-support structures

## Controlled variation
後續可變更服裝、背景、姿態、表情或鏡位，但只有使用者允許變更的 scope 可變；身份錨點保持不變。

## Default composition behavior
- 主視覺優先呈現最能辨識同一角色的 Identity anchors。
- 未指定唯一版面時，`composition-advisor` 提供 3 組配置：可偏向 face identity、whole-structure identity、或 balanced identity；實際名稱與內容依角色素材調整。
- 缺少某類素材時不臆測補齊，以其他已知身份特徵重組版面。
