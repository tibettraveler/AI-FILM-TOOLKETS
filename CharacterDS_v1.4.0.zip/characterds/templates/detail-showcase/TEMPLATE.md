# Detail Showcase

## Positioning
CharacterDS 的 Dynamic Presentation 基礎模板。支援單角色、雙角色與多角色人物介紹、交叉展示、身份揭示與多變種 showcase。

## Output modes
- `motion-only`
- `static+motion-paired`
- `multi-variant-showcase`

## Assembly
```text
IDENTITY_ANCHORS
+ ASSET_BINDING
+ SHOT_OWNERSHIP
+ CONTINUITY_CHANNELS
+ MOTION / SHOT / REVEAL
+ NARRATIVE_TEMPLATE (optional)
+ VARIATION_CONTROL
+ PROMPT_ASSEMBLY_QC
```

## Single-character default
可採：
`setup -> build -> release -> settle/reveal`

## Duo / multi-character default
優先使用交叉而非同步鏡像：
- alternate focus
- call / response
- strong action / detail response
- motion-vector relay
- staggered reveal
- converging final reveal

## Source-faithful montage profile
使用者明確要求來源式 montage 時，可使用 15 秒 / 20 鏡 / 最終 reveal profile。此 profile 不是全域默認。

## Dynamic narrative templates
- `identity-reveal`
- `dress-up-final-reveal`
- `invisible-dressing-room`
- `material-showcase`
- `emotion-build-reveal`
- `signature-detail-intro`
- `duo-cross-showcase`
- `contrast-duet`
- `relay-reveal`
- `dual-final-reveal`

## Hard boundaries
- 角色既有 signature weapon / accessory 可作為 identity asset 綁定；不得把 A 的資產漂到 B。
- 換裝必須有明確 state change，不產生未指定的混合服裝。
- 角色切換時可延續 motion / rhythm / screen direction，但 identity / outfit / prop / anatomy 不跨角色繼承。
- 鏡像動作不是預設；重複 motion、shot scale、camera direction 應主動降低。
- 不把商品／物件設計或 production narrative control 併入本模板。
