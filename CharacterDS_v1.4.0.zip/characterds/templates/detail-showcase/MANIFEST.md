# TEMPLATE-DETAIL-SHOWCASE Manifest

```text
TEMPLATE_ID: detail-showcase
PURPOSE_CLASS: DYNAMIC_PRESENTATION
MEDIUM: VIDEO_PROMPT
TEMPLATE_FILE: TEMPLATE.md
ALLOWED_MODULES:
  - identity-core
  - anatomy-adaptation
  - quality-consistency
  - motion-continuity
  - shot-grammar
  - reveal-control
  - narrative-template-library
  - asset-binding
  - continuity-channels
  - cross-character-isolation
  - motion-variation-control
  - static-motion-bridge
  - showcase-advisor
  - prompt-assembly-qc
```

## Boundary
本模板是角色動態展示／人物介紹蒙太奇 family，不是 production 敘事影片生成控制 DS，也不負責新道具／商品設計。
